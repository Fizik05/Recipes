from rest_framework import viewsets, generics, status
from rest_framework.views import APIView
from rest_framework.decorators import action
from rest_framework.response import Response
from django.shortcuts import render, get_object_or_404, get_list_or_404

from .models import Recipe, Instruction, Category
from .serializers import RecipesSerializer, InstructionSerializer, CategorySerializer


class RecipeApiList(generics.ListCreateAPIView):
    queryset = Recipe.objects.all()
    serializer_class = RecipesSerializer


class RecipesByCategoriesAPIView(APIView):
    def get(self, request, slug):
        category = get_object_or_404(Category, slug=slug)
        recipes = get_list_or_404(Recipe, category=category.id)
        serializer = RecipesSerializer(recipes, many=True)

        return Response(serializer.data)


class InformationAboutRecipeAPIView(APIView):
    def get(self, request, id):
        recipe = get_object_or_404(Recipe, id=id)
        serializer = RecipesSerializer(recipe)

        return Response(serializer.data)


class InstructionsAboutRecipe(APIView):
    def get(self, request, id):
        instructions = get_list_or_404(Instruction, recipe=id)
        serializer = InstructionSerializer(instructions, many=True)

        return Response(serializer.data)


class InstructionByStep(APIView):
    def get(self, request, id, step):
        instruction = get_object_or_404(Instruction, recipe=id, number_of_step=str(step))
        serializer = InstructionSerializer(instruction)

        return Response(serializer.data)
