from django.urls import path, include
from rest_framework.routers import DefaultRouter

from . import views


app_name = "recipes"


router = DefaultRouter()
#router.register("recipes/instruction", views.InstructionViewSet, "Instruction")
#router.register("recipes", views.RecipeViewSet, "Recipes")
#router.register("recipes/<str:slug>", views.CategoryViewSet, "Category")

urlpatterns = [
    #path("", include(router.urls)),
    path("recipes/", views.RecipeApiList.as_view()),
    path("recipes/<int:id>/", views.InformationAboutRecipeAPIView.as_view()),
    path("recipes/<str:slug>/", views.RecipesByCategoriesAPIView.as_view()),
    path("recipes/<int:id>/instructions/", views.InstructionsAboutRecipe.as_view()),
    path("recipes/<int:id>/instructions/<int:step>/", views.InstructionByStep.as_view()),
]
